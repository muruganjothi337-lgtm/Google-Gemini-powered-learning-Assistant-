const tabs = document.querySelectorAll(".tab");
const panels = document.querySelectorAll(".panel");
const resultBox = document.querySelector("#result");
const resultContent = document.querySelector("#result-content");
let lastResult = "";

tabs.forEach(tab => tab.addEventListener("click", () => {
  tabs.forEach(t => t.classList.toggle("active", t === tab));
  panels.forEach(p => p.classList.toggle("active", p.id === tab.dataset.panel));
}));

function renderValue(key, value) {
  if (key === "quiz" && Array.isArray(value)) {
    resultContent.innerHTML = "";
    value.forEach((item, i) => {
      const card = document.createElement("div"); card.className = "quiz-card";
      const heading = document.createElement("h3"); heading.textContent = `${i+1}. ${item.question}`; card.append(heading);
      const form = document.createElement("div");
      (item.options || []).forEach(option => {
        const label = document.createElement("label"); label.className = "option";
        const radio = document.createElement("input"); radio.type = "radio"; radio.name = `q${i}`; radio.value = option;
        label.append(radio, document.createTextNode(option)); form.append(label);
      });
      const check = document.createElement("button"); check.className = "secondary"; check.type = "button"; check.textContent = "Check answer";
      const feedback = document.createElement("div"); feedback.className = "feedback"; feedback.hidden = true;
      check.addEventListener("click", () => {
        const selected = form.querySelector("input:checked");
        feedback.hidden = false;
        feedback.textContent = selected ? `${selected.value === item.answer ? "Correct!" : "Not quite."} ${item.explanation || ""} Correct answer: ${item.answer}` : "Choose an answer first.";
      });
      card.append(form, check, feedback); resultContent.append(card);
    });
    lastResult = JSON.stringify(value, null, 2);
    return;
  }
  if (Array.isArray(value)) {
    resultContent.innerHTML = "";
    value.forEach((item, i) => {
      const card = document.createElement("div"); card.className = "path-card";
      const title = document.createElement("h3"); title.textContent = item.week ? `Week ${item.week}: ${item.focus || ""}` : (item.title || `Step ${i+1}`);
      card.append(title);
      Object.entries(item).filter(([k]) => !["week","focus","title"].includes(k)).forEach(([k,v]) => {
        const p = document.createElement("p"); p.textContent = `${k.replaceAll("_"," ")}: ${typeof v === "string" ? v : JSON.stringify(v)}`; card.append(p);
      });
      resultContent.append(card);
    });
    lastResult = JSON.stringify(value, null, 2);
    return;
  }
  const div = document.createElement("div"); div.className = "answer-text"; div.textContent = String(value);
  resultContent.replaceChildren(div); lastResult = String(value);
}

document.querySelectorAll("form[data-endpoint]").forEach(form => {
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const button = form.querySelector("button[type=submit],button:not([type])");
    const oldText = button.textContent; button.disabled = true; button.textContent = "Working…";
    resultBox.hidden = false; resultContent.textContent = "Preparing your learning result…";
    const payload = Object.fromEntries(new FormData(form).entries());
    for (const k of ["count", "weeks"]) if (payload[k]) payload[k] = Number(payload[k]);
    try {
      const response = await fetch(form.dataset.endpoint, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(payload)});
      const data = await response.json();
      if (!response.ok) throw new Error(data.detail ? JSON.stringify(data.detail) : "Request failed");
      const key = form.dataset.output;
      renderValue(key, data[key]);
      resultBox.scrollIntoView({behavior:"smooth", block:"start"});
    } catch (error) {
      resultContent.innerHTML = ""; const p = document.createElement("p"); p.className = "error"; p.textContent = error.message; resultContent.append(p);
    } finally { button.disabled = false; button.textContent = oldText; }
  });
});

document.querySelector("#copy").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(lastResult); document.querySelector("#copy").textContent = "Copied!"; }
  catch { document.querySelector("#copy").textContent = "Copy unavailable"; }
  setTimeout(() => document.querySelector("#copy").textContent = "Copy result", 1400);
});
