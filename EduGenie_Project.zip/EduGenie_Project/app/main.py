from pathlib import Path
import os
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel, Field
from app.services import (
    answer_question, explain_concept, generate_quiz,
    create_learning_path, summarize_text
)

ROOT = Path(__file__).resolve().parent
app = FastAPI(title="EduGenie API", version="1.0.0",
              description="Lightweight AI-powered educational assistant")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")
templates = Jinja2Templates(directory=ROOT / "templates")

class AskRequest(BaseModel):
    question: str = Field(min_length=2, max_length=2000)

class ExplainRequest(BaseModel):
    topic: str = Field(min_length=2, max_length=500)
    level: str = Field(default="beginner", max_length=40)

class QuizRequest(BaseModel):
    topic: str = Field(min_length=2, max_length=300)
    count: int = Field(default=5, ge=1, le=10)
    level: str = Field(default="beginner", max_length=40)

class PathRequest(BaseModel):
    topic: str = Field(min_length=2, max_length=300)
    weeks: int = Field(default=4, ge=1, le=24)
    level: str = Field(default="beginner", max_length=40)

class SummaryRequest(BaseModel):
    text: str = Field(min_length=20, max_length=20000)
    length: str = Field(default="short", max_length=20)

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.get("/health")
async def health():
    return {"status": "ok", "service": "EduGenie"}

@app.post("/api/ask")
async def ask(payload: AskRequest):
    return {"answer": await answer_question(payload.question)}

@app.post("/api/explain")
async def explain(payload: ExplainRequest):
    return {"explanation": await explain_concept(payload.topic, payload.level)}

@app.post("/api/quiz")
async def quiz(payload: QuizRequest):
    return {"quiz": await generate_quiz(payload.topic, payload.count, payload.level)}

@app.post("/api/learning-path")
async def learning_path(payload: PathRequest):
    return {"learning_path": await create_learning_path(payload.topic, payload.weeks, payload.level)}

@app.post("/api/summarize")
async def summarize(payload: SummaryRequest):
    return {"summary": await summarize_text(payload.text, payload.length)}
