"""AI service layer with optional cloud-model support and demo fallbacks."""
import json
import os
from typing import Any

def _client():
    key = os.getenv("OPENAI_API_KEY", "").strip()
    if not key:
        return None
    try:
        from openai import AsyncOpenAI
        return AsyncOpenAI(api_key=key)
    except Exception:
        return None

async def _ask_model(instructions: str, prompt: str) -> str | None:
    client = _client()
    if client is None:
        return None
    try:
        response = await client.chat.completions.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": instructions},
                {"role": "user", "content": prompt},
            ],
            temperature=0.4,
        )
        return response.choices[0].message.content or None
    except Exception:
        return None

async def answer_question(question: str) -> str:
    result = await _ask_model(
        "You are EduGenie, a careful educational assistant. Answer clearly and concisely. "
        "If uncertain, say so and encourage verification.",
        question,
    )
    if result:
        return result
    q = question.lower()
    if "largest ocean" in q:
        return "The Pacific Ocean is the largest ocean on Earth."
    if "river" in q and "ocean" in q:
        return "A river is flowing freshwater that usually moves toward a lake, another river, or the sea. An ocean is a vast body of salt water."
    return ("Demo mode: I received your question: " + question +
            ". Add OPENAI_API_KEY to enable cloud AI answers. Check important facts with trusted learning resources.")

async def explain_concept(topic: str, level: str) -> str:
    result = await _ask_model(
        "Explain educational concepts accurately using plain language, a short example, and key takeaway.",
        f"Explain {topic} for a {level} learner.",
    )
    if result:
        return result
    if "pythag" in topic.lower():
        return ("For a right-angled triangle, the square of the longest side (hypotenuse) equals "
                "the sum of the squares of the other two sides: a² + b² = c². "
                "Example: sides 3 and 4 give a hypotenuse of 5 because 9 + 16 = 25.")
    return f"Demo mode: {topic} can be studied by defining it, identifying its main parts, and working through one simple example. Add OPENAI_API_KEY for a tailored explanation."

async def generate_quiz(topic: str, count: int, level: str) -> list[dict[str, Any]]:
    result = await _ask_model(
        "Create multiple-choice educational quiz questions. Return ONLY valid JSON array. "
        "Each item must contain question, options (array of 4 strings), answer (exact option), and explanation.",
        f"Topic: {topic}. Level: {level}. Number of questions: {count}.",
    )
    if result:
        try:
            parsed = json.loads(result)
            if isinstance(parsed, list) and parsed:
                return parsed[:count]
        except json.JSONDecodeError:
            pass
    if "pythag" in topic.lower():
        bank = [
            {"question": "Which triangle uses the Pythagorean theorem?", "options": ["Right-angled triangle", "Equilateral triangle only", "Any quadrilateral", "Circle"], "answer": "Right-angled triangle", "explanation": "The theorem applies to right-angled triangles."},
            {"question": "What is the formula?", "options": ["a + b = c", "a² + b² = c²", "a² - b² = c", "2a + 2b = c"], "answer": "a² + b² = c²", "explanation": "The two shorter sides' squares add to the hypotenuse's square."},
            {"question": "If the shorter sides are 3 and 4, what is the hypotenuse?", "options": ["5", "6", "7", "12"], "answer": "5", "explanation": "3² + 4² = 9 + 16 = 25, and √25 = 5."},
            {"question": "Which side is the hypotenuse?", "options": ["The side opposite the right angle", "The shortest side", "Any side", "The base in every triangle"], "answer": "The side opposite the right angle", "explanation": "It is also the longest side in a right triangle."},
            {"question": "If a=5 and b=12, what is c?", "options": ["13", "17", "10", "60"], "answer": "13", "explanation": "25 + 144 = 169, so c = 13."},
        ]
        return bank[:count]
    return [{"question": f"Demo question {i+1}: Which is a good first step when learning {topic}?",
             "options": ["Understand the basic definition", "Skip all examples", "Memorize without understanding", "Avoid practice"],
             "answer": "Understand the basic definition",
             "explanation": "Start with core ideas, then practice."} for i in range(count)]

async def create_learning_path(topic: str, weeks: int, level: str) -> list[dict[str, Any]] | str:
    result = await _ask_model(
        "Create a practical learning path with weekly milestones, topics, practice tasks, and resources to seek. Return ONLY valid JSON array.",
        f"Topic: {topic}; level: {level}; duration: {weeks} weeks.",
    )
    if result:
        try:
            parsed = json.loads(result)
            if isinstance(parsed, list) and parsed:
                return parsed
        except json.JSONDecodeError:
            pass
    stages = [
        ("Foundations", "Learn core vocabulary and concepts; make short notes."),
        ("Core skills", "Work through guided examples and beginner exercises."),
        ("Applied practice", "Build a small practical task and review mistakes."),
        ("Consolidation", "Complete a mini-project, revise, and assess your progress."),
    ]
    return [{"week": i+1, "focus": stages[min(i, 3)][0],
             "topics": f"{topic}: " + ["introductory concepts and terminology", "essential syntax or methods", "realistic examples and problem solving", "review and project practice"][min(i, 3)],
             "task": stages[min(i, 3)][1]} for i in range(weeks)]

async def summarize_text(text: str, length: str) -> str:
    result = await _ask_model(
        "Summarize educational text faithfully. Keep important ideas and do not invent details.",
        f"Length preference: {length}. Text:\n{text}",
    )
    if result:
        return result
    sentences = [s.strip() for s in text.replace("\n", " ").split(".") if s.strip()]
    limit = 2 if length == "short" else 5
    return "Demo summary: " + ". ".join(sentences[:limit]) + ("." if sentences else "")
