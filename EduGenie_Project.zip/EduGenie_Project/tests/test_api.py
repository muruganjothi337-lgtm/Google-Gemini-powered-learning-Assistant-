from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_home_page():
    response = client.get("/")
    assert response.status_code == 200
    assert "EduGenie" in response.text

def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"

def test_largest_ocean_demo():
    response = client.post("/api/ask", json={"question": "Which is the largest ocean?"})
    assert response.status_code == 200
    assert "Pacific" in response.json()["answer"]

def test_quiz_validation():
    response = client.post("/api/quiz", json={"topic": "Math", "count": 99})
    assert response.status_code == 422
