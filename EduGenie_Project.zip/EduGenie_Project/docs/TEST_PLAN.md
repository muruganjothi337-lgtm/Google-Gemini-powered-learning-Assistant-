# Test Plan

| ID | Test | Input | Expected result |
|---|---|---|---|
| T01 | Home page | `GET /` | HTTP 200 and EduGenie page |
| T02 | Health check | `GET /health` | `status=ok` |
| T03 | Known ocean question | `POST /api/ask` | Response mentions Pacific in demo mode |
| T04 | Invalid quiz count | `count=99` | HTTP 422 |
| T05 | Empty question | empty question | Validation error |
| T06 | Quiz UI | Generate quiz | Questions and answer checks appear |
| T07 | Learning path | SQL, 4 weeks | Weekly milestones returned |
| T08 | Summary | valid study text | Summary string returned |

Run automated tests with `pytest`. Cloud-model tests may vary with provider availability, cost, and output; test using a controlled test key if needed.
