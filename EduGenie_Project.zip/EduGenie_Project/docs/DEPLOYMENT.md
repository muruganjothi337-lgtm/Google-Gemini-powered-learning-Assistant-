# Deployment Notes

For local development:
```bash
uvicorn app.main:app --reload
```

For a simple production-like run:
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

Use a managed secret store or environment variables for API keys. Place the app behind HTTPS and a reverse proxy when exposing it publicly. Configure request limits, rate limiting, monitoring, and a clear privacy notice. Do not use `--reload` in production.
