# Product Roadmap

## Current prototype
- Question answering
- Simplified explanations
- Multiple-choice quizzes
- Learning paths
- Text summaries
- Responsive browser UI
- Optional cloud model and demo fallback

## Next
1. Add user accounts and saved progress.
2. Store learning plans and quiz results in SQLite or PostgreSQL.
3. Add PDF extraction with file-size and type validation.
4. Add Tamil and other language support.
5. Add accessible keyboard navigation and richer screen-reader feedback.
6. Add provider timeouts, structured-output validation, usage limits, and observability.
7. Add deployment automation and a staging environment.
