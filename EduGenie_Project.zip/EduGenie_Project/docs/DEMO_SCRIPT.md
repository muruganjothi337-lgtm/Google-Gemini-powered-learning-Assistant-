# Demo / Presentation Script

1. Introduce EduGenie as a lightweight AI-powered learning assistant.
2. Open the Ask AI tab and ask, “Which is the largest ocean?”
3. Open Explain and enter “The Pythagoras theorem.”
4. Generate a quiz for the same topic and check one answer.
5. Open Learning Path, enter “SQL,” choose four weeks, and create the roadmap.
6. Paste a paragraph into Summarize and show the concise result.
7. Explain the technology: FastAPI backend, browser frontend, and optional cloud AI provider.
8. Close by discussing future work: multilingual support, saved progress, and PDF study notes.

Mention honestly whether the live cloud model is configured or the demo fallback is being used.
