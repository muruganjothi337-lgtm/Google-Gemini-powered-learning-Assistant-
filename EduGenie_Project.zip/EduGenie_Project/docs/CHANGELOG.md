# Changelog

## 1.0.0 — Initial project prototype
- Added FastAPI web application.
- Added Ask, Explain, Quiz, Learning Path, and Summarize tools.
- Added responsive frontend.
- Added optional cloud model adapter and demo fallbacks.
- Added basic tests and project documentation.
