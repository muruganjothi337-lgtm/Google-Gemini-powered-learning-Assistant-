# Development Notes

## Code organization
- `main.py`: web routes and request validation.
- `services.py`: AI adapter and fallback content.
- `templates/index.html`: semantic page structure.
- `static/style.css`: layout and responsive styles.
- `static/app.js`: fetch calls and safe text rendering.

## Design decisions
- Pydantic validates request fields and constrains quiz count and learning-path duration.
- Frontend uses `textContent` for model-produced text to reduce HTML injection risk.
- Cloud AI is optional so the interface can be demonstrated without credentials.
- The service layer catches provider failures and returns demo fallbacks; production deployments should log provider errors safely and distinguish failures more explicitly.
