# User Guide

1. Start the server using the instructions in the root README.
2. Open `http://127.0.0.1:8000` in a browser.
3. Choose a tool tab: Ask AI, Explain, Generate Quiz, Learning Path, or Summarize.
4. Enter the requested topic or text and submit.
5. Read the result. For quizzes, select an option and press **Check answer**.
6. Use **Copy result** to copy the generated output.

### Example prompts
- Ask AI: “Which is the largest ocean?”
- Explain: “The Pythagoras theorem”
- Quiz: “The Pythagoras theorem”
- Learning path: “SQL from beginner to advanced”
- Summarize: paste a textbook paragraph of at least 20 characters.

If you see a demo-mode message, configure a cloud API key using the README instructions to enable model responses.
