# Privacy and Responsible Use

- Do not enter passwords, account numbers, private records, or other sensitive personal information.
- A configured cloud AI provider may process the submitted prompt/text. Review that provider's privacy terms before use.
- Keep API credentials outside source files and out of screenshots or public repositories.
- The prototype does not store user history in a database.
- AI-generated answers may contain mistakes. Verify important facts, especially for exams or safety-related topics.
- Before public release, add appropriate access controls, rate limiting, input-size limits, monitoring, and a privacy notice.
