# Architecture

```text
Browser (HTML/CSS/JavaScript)
          |
          | JSON over HTTP
          v
FastAPI routes + Pydantic validation
          |
          v
Service layer (app/services.py)
          |
          +---- configured cloud AI provider
          |
          +---- clearly labeled demo fallback
```

The frontend handles form submission and result presentation. The backend validates user inputs, delegates to service functions, and returns JSON. The optional model adapter isolates provider-specific code from the routes.
