# API Reference

All POST endpoints accept JSON and return JSON. Validation errors use HTTP 422.

## Ask
`POST /api/ask`
```json
{"question":"Which is the largest ocean?"}
```
Response:
```json
{"answer":"The Pacific Ocean is the largest ocean on Earth."}
```

## Explain
`POST /api/explain`
```json
{"topic":"The Pythagoras theorem","level":"beginner"}
```
Response shape: `{"explanation":"..."}`

## Quiz
`POST /api/quiz`
```json
{"topic":"The Pythagoras theorem","count":5,"level":"beginner"}
```
Response shape: `{"quiz":[{"question":"...","options":["..."],"answer":"...","explanation":"..."}]}`

## Learning path
`POST /api/learning-path`
```json
{"topic":"SQL","weeks":4,"level":"beginner"}
```
Response shape: `{"learning_path":[{"week":1,"focus":"...","topics":"...","task":"..."}]}`

## Summarize
`POST /api/summarize`
```json
{"text":"At least twenty characters of educational text...","length":"short"}
```
Response shape: `{"summary":"..."}`

## Health
`GET /health` returns `{"status":"ok","service":"EduGenie"}`.
