# FAQ

**Does it need an API key?** No for the demo fallback; yes for live cloud-model answers.

**Why does it show demo mode?** No key may be configured, or the provider may be unavailable. Check environment variables and provider access.

**Can I run it on a Mac M1?** Yes, with a compatible Python installation and dependencies.

**Does it save my progress?** Not in this prototype. It has no user database.

**Can I trust every answer?** No. Verify important content with trusted sources.

**How do I run tests?** Install dependencies and execute `pytest`.
