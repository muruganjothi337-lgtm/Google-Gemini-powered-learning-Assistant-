# Future Database Design

The current prototype does not persist data. If persistence is added, a minimal relational design could use:

- `users`: id, display_name, email_hash, created_at
- `learning_paths`: id, user_id, topic, level, duration_weeks, created_at
- `quiz_attempts`: id, user_id, topic, score, total_questions, created_at
- `study_notes`: id, user_id, title, content, created_at, updated_at

Use foreign keys and access controls. Avoid storing unnecessary personal information, and define retention and deletion policies before launch.
