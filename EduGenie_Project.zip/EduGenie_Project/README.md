# EduGenie — AI-Powered Learning Assistant

EduGenie is a lightweight educational web app built with **FastAPI** and a simple **HTML/CSS/JavaScript** frontend. It supports:
- Ask questions and get concise answers
- Simplify complex concepts
- Generate topic quizzes
- Build structured learning paths
- Summarize educational text

## Requirements
- Python 3.10+
- An AI provider API key for live AI responses (optional; demo fallback works without one)

## Quick start
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```
Open http://127.0.0.1:8000

## Configure cloud AI (optional)
Set `OPENAI_API_KEY` in your environment. If set, EduGenie attempts to use the OpenAI API; if not, the app uses a clearly labeled educational demo fallback. Do not commit API keys to source control.

```bash
# macOS/Linux
export OPENAI_API_KEY="your-key"
# Windows PowerShell
$env:OPENAI_API_KEY="your-key"
```

## API endpoints
- `GET /` — web interface
- `GET /health` — health check
- `POST /api/ask` — question answering
- `POST /api/explain` — simplified explanation
- `POST /api/quiz` — quiz generation
- `POST /api/learning-path` — learning path generation
- `POST /api/summarize` — text summary

## Project structure
See `docs/PROJECT_REPORT.md` and `docs/FILE_GUIDE.md`.

## Notes
The fallback mode is for demonstrations and does not claim to be a real AI model. Validate AI-generated educational content before relying on it.
